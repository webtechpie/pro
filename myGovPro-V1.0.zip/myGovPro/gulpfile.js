var gulp = require('gulp');

var less = require('gulp-less');

// compile less
gulp.task('less', function(){
	return gulp.src('app/less/styles.less')
	.pipe(less())
	.pipe(gulp.dest('app/css/'))
});


// Automate for less - gulp watch
gulp.task('watch', function(){
	gulp.watch('app/less/styles.less', ['less'])
})