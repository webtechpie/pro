/*
	Md Hidaytullah Rahmani
	v1.0.0.0
*/


/*jQuery Custom Code*/

$(document).ready(function(){
	$(".login-form").on("click",".sign-in", function(){
		window.location.href="welcome.html";
		console.log("hidayt");
	});
});


// Angular App
var app = angular.module("gov-pro", []);
    app.controller("mainCtrl", function($scope){
        $scope.myApp = {
            title: "Gov Pro v2",
            welcomeTitle: "Electronic Vehicle System",
			customer: "Johnny"
        }
});